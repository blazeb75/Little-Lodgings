﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectExtensions
{
	public static class ExtendDictionary
	{
		//public static int KeyLike<string, int>(this Dictionary<string, int> dict, string key, int defaultValue)
		//{
		//	int value = defaultValue;
		//	return value;
		//}
	}
}
