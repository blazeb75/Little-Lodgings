﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using ObjectExtensions;

namespace ParserCommon
{
    public enum DebugLevel { Off, Minimal, Info, Full }

    public class DebugMsgItem 
    {
        public object     Parent     { get; set; }
		public string     ParentName { get; set; }
        public DebugLevel Level      { get; set; }
    }

    /// <summary>
    /// Static class that displays debug.writeline messages based on the previously 
    /// specified DebugLevel. If the parent object is not found in the list of subsribers, 
    /// or if the level is less than the specified level for that object, it is not 
    /// written to the output window.
    /// </summary>
    public static class DebugMsgs
    {
        public static List<DebugMsgItem> subscribers = new List<DebugMsgItem>();

		/// <summary>
		/// Add an object to the subscriber list
		/// </summary>
		/// <param name="parent">The object to be added to the subscriber list</param>
		/// <param name="level">The minimum message debug level for which messages will be applied.</param>
		/// <param name="parentName">The name of the parent object (default = "")</param>
        public static void Add(object parent, DebugLevel level, string parentName = "")
        {
			if (parent != null)
			{
				var found = DebugMsgs.subscribers.FirstOrDefault(x=>x.Parent == parent);
				if (found == null)
				{
					DebugMsgs.subscribers.Add(new DebugMsgItem() { Parent = parent, Level = level, ParentName = parentName });
				}
				else
				{
					found.Level = level;
				}
			}
        }

		/// <summary>
		/// Shows the specified message in the output window for the specified object if the DebugLevel is 
		/// appropriate.
		/// </summary>
		/// <param name="obj">The object requesting the process</param>
		/// <param name="msg">The message to be posted</param>
		/// <param name="level">The level at which the message can be posted to the output window</param>
        public static void Show(object obj, string msg, DebugLevel level)
        {
			if (!string.IsNullOrEmpty(msg))
			{
				var found = DebugMsgs.subscribers.FirstOrDefault(x=>x.Parent == obj);
				if (found != null)
				{
					if ((int)level <= (int)found.Level)
					{
						Debug.WriteLine(string.Concat(found.ParentName, string.IsNullOrEmpty(found.ParentName.Trim()) ? " - " : "", msg));
					}
				}
			}
        }

		/// <summary>
		/// Writes to both the output window AND the application event log.
		/// </summary>
		/// <param name="obj">The object requesting the process</param>
		/// <param name="msg">The message to be posted</param>
		/// <param name="level">The level at which the message can be posted to the output window</param>
		/// <param name="logType">The event log entry type</param>
		/// <param name="ex">The exception that triggered this method call (if applicable)</param>
		/// <remarks>This method only supports Information, Warning, and Error event types are supported </remarks>
        public static void Show(object obj, string msg, DebugLevel level, EventLogEntryType logType, Exception ex = null)
        {
			if (!string.IsNullOrEmpty(msg))
			{
				var found = DebugMsgs.subscribers.FirstOrDefault(x=>x.Parent == obj);
				if (found != null)
				{
					if ((int)level <= (int)found.Level)
					{
						Debug.WriteLine(string.Concat(found.ParentName, string.IsNullOrEmpty(found.ParentName.Trim()) ? " - " : "", msg));
						if (logType == EventLogEntryType.Information)
						{
							AppLog.Info(msg);
						}
					}
					switch (logType)
					{
						case EventLogEntryType.Error   : AppLog.Error(msg, ex); break;
						case EventLogEntryType.Warning : AppLog.Warning(msg);   break;
					}
				}
			}
        }

		/// <summary>
		/// Shows a line of separator characters, using the specified length of specified 
		/// character
		/// </summary>
		/// <param name="obj">The object requesting the process</param>
		/// <param name="level">The level at which the message can be posted to the output window</param>
		/// <param name="character">Thecharacter to use as a separator</param>
		/// <param name="length">The length of the separator string (default length = 80)</param>
		public static void ShowSeparator(object obj, DebugLevel level, char character='-', int length=80)
		{
			// make sure we have a character specified
			character = (character.IsAsciiNonPrintable()) ? '-' : character;
			// make sure we have a length of at least 1 
			length = Math.Min(1, length);

            var found = DebugMsgs.subscribers.FirstOrDefault(x=>x.Parent == obj);
            if (found != null)
            {
                if ((int)level <= (int)found.Level)
                {
					string separator = new String(character, length);
					Debug.WriteLine(separator);
				}
			}
		}

		/// <summary>
		/// Shows the specified number of empty lines (default/minimum is 1 line).
		/// </summary>
		/// <param name="obj">The object requesting the process</param>
		/// <param name="level">The level at which the message can be posted to the output window</param>
		/// <param name="number">The number of blank lines to display (default = 1)</param>
		public static void ShowEmptyLine(object obj, DebugLevel level, int number=1)
		{
			// make sure we're going to show at least 1 blank line
			number = Math.Min(1, number);

            var found = DebugMsgs.subscribers.FirstOrDefault(x=>x.Parent == obj);
            if (found != null)
            {
                if ((int)level <= (int)found.Level)
                {
					for (int i = 1; i <= number; i++)
					{
						Debug.WriteLine("");
					}
				}
			}
		}

    }
}
