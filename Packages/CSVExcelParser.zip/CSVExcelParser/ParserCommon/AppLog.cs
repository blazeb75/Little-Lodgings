﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObjectExtensions;

namespace ParserCommon
{
	/// <summary>
	/// Allows the application to write to the Windows Application Events log
	/// </summary>
	public static class AppLog
	{
		private static EventLog Log    { get; set; }
		public  static bool     IsOpen { get { return (AppLog.Log != null); } }

		public static void Close()
		{
			if (Log != null)
			{
				Log.Close();
			}
		}

		/// <summary>
		/// Open the application even log for the named application.
		/// </summary>
		/// <param name="appName">The name of the application</param>
		public static void Open(string appName)
		{
			if (AppLog.Log == null)
			{
				AppLog.Log = new EventLog();
				if (!EventLog.SourceExists(appName))
				{
					EventLog.CreateEventSource(appName, "Application");
				}
				AppLog.Log.Source = appName;
			}
		}

		/// <summary>
		/// Write to the application event log
		/// </summary>
		/// <param name="msg">The message to write</param>
		/// <param name="entryType">The type of event entry (Info, Warinng, Error)</param>
		/// <param name="entryID">The ID of the entry</param>
		/// <param name="category">The catghory of the entry</param>
		/// <param name="rawData">Raw data that accompanies the entry, such as an exception stack trace, etc (defalt value = null)</param>
		/// <remarks>If the log has not been opened, this method will not do anything.</remarks>
		public static void Write(string msg, EventLogEntryType entryType,  int entryID, short category, byte[] rawData = null)
		{
			if (AppLog.Log != null)
			{
				Log.WriteEntry(msg, entryType, entryID, category, rawData);
			}
		}

		/// <summary>
		/// Write an Error event to the application event log. The exception message and 
		/// stack trace in the exception will be added to the specified message
		/// </summary>
		/// <param name="msg">The message to write</param>
		/// <param name="ex">The exception that triggered the call to this method</param>
		/// <param name="entryID">The ID of the entry</param>
		/// <param name="category">The catghory of the entry</param>
		/// <remarks>If the log has not been opened, this method will not do anything.</remarks>
		public static void Write(string msg, Exception ex, int entryID, short category)
		{
			if (AppLog.Log != null)
			{
				msg = string.Concat(msg, (string.IsNullOrEmpty(msg)) ? "" : "\r\n\r\n", ex.Message, "\r\n\r\n");
				AppLog.Write(msg, EventLogEntryType.Error, entryID, category, ex.StackTrace.ToByteArray());
			}
		}

		//================================================
		// Info overloads
		//================================================

		public static void Info(string msg)
		{
			AppLog.Write(msg, EventLogEntryType.Information, 0, 0, null);
		}

		public static void Info(string msg, int entryID)
		{
			AppLog.Write(msg, EventLogEntryType.Information, entryID, 0, null);
		}

		public static void Info(string msg, short category)
		{
			AppLog.Write(msg, EventLogEntryType.Information, 0, category, null);
		}

		public static void Info(string msg, int entryID, short category)
		{
			AppLog.Write(msg, EventLogEntryType.Information, entryID, category, null);
		}

		//================================================
		// Warning overloads
		//================================================

		public static void Warning(string msg)
		{
			AppLog.Write(msg, EventLogEntryType.Warning, 0, 0, null);
		}

		public static void Warning(string msg, int entryID)
		{
			AppLog.Write(msg, EventLogEntryType.Warning, entryID, 0, null);
		}

		public static void Warning(string msg, short category)
		{
			AppLog.Write(msg, EventLogEntryType.Warning, 0, category, null);
		}

		public static void Warning(string msg, int entryID, short category)
		{
			AppLog.Write(msg, EventLogEntryType.Warning, entryID, category, null);
		}

		//================================================
		// Error overloads
		//================================================

		public static void Error(string msg)
		{
			AppLog.Write(msg, EventLogEntryType.Error, 0, 0, null);
		}

		public static void Error(string msg, short category)
		{
			AppLog.Write(msg, EventLogEntryType.Error, 0, category, null);
		}

		public static void Error(int entryID, string msg)
		{
			AppLog.Write(msg, EventLogEntryType.Error, entryID, 0, null);
		}

		public static void Error(string msg, int entryID, short category)
		{
			AppLog.Write(msg, EventLogEntryType.Error, entryID, category, null);
		}

		public static void Error(Exception ex)
		{
			AppLog.Write(ex.Message, EventLogEntryType.Error, 0, 0, ex.StackTrace.ToByteArray());
		}
		
		public static void Error(Exception ex, int entryID)
		{
			AppLog.Write(ex.Message, EventLogEntryType.Error, entryID, 0, ex.StackTrace.ToByteArray());
		}
		
		public static void Error(Exception ex, short category)
		{
			AppLog.Write(ex.Message, EventLogEntryType.Error, 0, category, ex.StackTrace.ToByteArray());
		}

		public static void Error(Exception ex, int entryID, short category)
		{
			AppLog.Write(ex.Message, EventLogEntryType.Error, entryID, category, ex.StackTrace.ToByteArray());
		}

		public static void Error(string msg, Exception ex)
		{
			AppLog.Write(msg, ex, 0, 0);
		}

		public static void Error(string msg, Exception ex, int entryID)
		{
			AppLog.Write(msg, ex, entryID, 0 );
		}

		public static void Error(string msg, Exception ex, short category)
		{
			AppLog.Write(msg, ex, 0, category);
		}

		public static void Error(string msg, Exception ex, int entryID, short category)
		{
			AppLog.Write(msg, ex, entryID, category);
		}
	}
}
