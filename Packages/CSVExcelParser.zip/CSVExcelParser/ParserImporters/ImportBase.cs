﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ParserCommon;
using ObjectExtensions;
using System.IO;

namespace ParserImporters
{
	/// <summary>
	/// Represents the abstract base importer class, which provides functionality common 
	/// to both the ExcelImortBase and CsvImportBase classes (also abstract).
	/// </summary>
	public abstract class ImporterBase
	{
		/* === Properties ============================================================= */

		/// <summary>
		/// Get/set a flag indicating whether all fields are to be imported as strings.
		/// Default value is false.
		/// </summary>
		public bool AllFieldsAreStrings { get;set; }

		/// <summary>
		/// Get/set a flag indicating whether this object is initialized enough to import 
		/// the data
		/// </summary>
		public bool CanImport { get; set; }

		/// <summary>
		/// Get/set a list containing hints about each column, such as name, expected 
		/// data type, and other info. If this list is null when the import process is 
		/// started, this list is populated from what the file thinks the column is. If a 
		/// column type is anything other than a recognized type, we assume it's of the 
		/// type specified by the DefaultColumnHintType property.
		/// </summary>
		public ItemHints ColumnHints { get; set; }

        /// <summary>
		/// Get/set flag indicating whetehr or not empty rows should be delete from the 
		/// loaded data
		/// </summary>			           
		public bool DeleteEmptyRows { get; set; }

        /// <summary>
		/// Get/set the name of the XLSX file to open
		/// </summary>
		public string FileName { get; set; }

		/// <summary>
		/// Get/set a flag indicating the type of file being imported (CSV or EXCEL). 
		/// This field can be manually set, but the base class will usually set it 
		/// based on the filename extension.
		/// </summary>
		public ImportFileType FileType { get; set; }

		/// <summary>
		/// Get/set a flag that indicates whether we limit automatic type detection to 
		/// just the first row of data. If this is false, the code will evaluate all 
		/// rows and use the most appropriate column type based on the data in all 
		/// the rows. Default value is false.
		/// </summary>
		public bool FirstRowDeterminesType { get; set; }

		/// <summary>
		/// Get/set a flag indicating whether or not the first row is a header
		/// </summary>
		public bool FirstRowIsHeader { get; set; }

		/// <summary>
		/// Get/set the data retrieved from the imported file.
		/// </summary>			           
		public DataTable ImportedData { get; set; }

		/// <summary>
		/// Get/set the name of the table into which the imported data will be inserted.
		/// </summary>
		public string ImportedTableName { get; set; }

		/// <summary>
		/// Get/set the number of rows that were deleted in the RemoveEmptyRows() method.
		/// </summary>
		public int RemovedRowCount { get; set; }

		/* === Abstract methods ======================================================= */

        public abstract void Import();

		/* === Constructors =========================================================== */

        /// <summary>
        /// Constructor for CSV files.
        /// </summary>
        /// <param name="filename">The name of the file to load</param>
        public ImporterBase(string filename)
        {
            this.FileName = filename;
        }

		/* === Protected methods ====================================================== */

		/// <summary>
		/// Initializes class properties and performs sanity checks.
		/// </summary>
		protected virtual void Init()
		{
			DebugMsgs.Add(this, DebugLevel.Full, "ImportBase");

			this.DoSanityChecks();

			this.ImportedTableName      = string.Empty;
            this.FirstRowIsHeader       = true;
			this.ColumnHints            = null;
			this.DeleteEmptyRows        = true;
			this.FirstRowDeterminesType = false;
			this.AllFieldsAreStrings    = false;
		}

		/// <summary>
		/// Performs sanity checks on the filename.
		/// </summary>
		protected virtual void DoSanityChecks()
		{
			this.CanImport = false;
			if (string.IsNullOrEmpty(this.FileName))
			{
				throw new ParserAgentException(ParserExceptionEnum.InvalidFileName);
			}
			else
			{
				if (!File.Exists(this.FileName))
				{
					throw new ParserAgentException(ParserExceptionEnum.ImportFileNotFound, new FileNotFoundException(this.FileName));
				}
			}
            this.CanImport = true;
		}

		/// <summary>
		/// Calls all of the methods involved in processing data loaded from the file. 
		/// All of the methods called here operate on a DataTable.
		/// </summary>
		protected virtual void ProcessData()
		{
			// remove empty rows (if configured to do so)
			this.RemoveEmptyRows();

			// remove linefeeds, spaces, and non-alphanumeric characters from 
			// column names
			this.NormalizeNames();

			// Create column hints list if necessary. If you want to use your own, 
			// instantiate it in your derived class BEFORE calling the Import() 
			// method.
			this.CreateColumnHints();

			// Correct the datatypes in the ImportedData object based on the 
			// ColumnHints object.
            this.SetColumnTypes();
        }

		/// <summary>
		/// If DeleteEmptyRows property is true, removes empty rows (all columns = DBNull) 
		/// from the loaded excel data.
		/// </summary>
		protected virtual void RemoveEmptyRows()
		{
			this.RemovedRowCount = 0;
			if (this.DeleteEmptyRows)
			{
				for (int i = this.ImportedData.Rows.Count-1; i >= 0; i--)
				{
					DataRow row = this.ImportedData.Rows[i];
					if (row.ItemArray.All(x=>x is DBNull || string.IsNullOrEmpty(x.ToString())))
					{
						this.ImportedData.Rows.Remove(row);
						this.RemovedRowCount++;
					}
				}
			}
		}

		/// <summary>
		/// If the first row is a header row, this method changes ExcelData.Columns to the 
		/// contents of the first row of the table, and the first row is deleted. The 
		/// column names (and table name) are massaged to replace all non-alphanumeric 
		/// characters with underscores, as well as trimming leading/trailing spaces.
		/// </summary>
		/// <param name="dt"></param>
		protected virtual void NormalizeNames()
		{
			// If the first row is the header, pull the names from the first row, and 
			// delete the row.
			if (this.FirstRowIsHeader)
			{
				// first row
				DataRow headerRow = this.ImportedData.Rows[0];

				// processe each column
				for (int i = 0; i < headerRow.ItemArray.Count(); i++)
				{
					// to ease typing
					DataColumn excelColumn = this.ImportedData.Columns[i];
					string rowColumn = (string)headerRow.ItemArray[i];

					// Set the column name from the first row of the data
					//                        if the column in the row is null/empty
					excelColumn.ColumnName = (string.IsNullOrEmpty(rowColumn)
											// keep the name we already have
											  ? excelColumn.ColumnName
											// otherwise set the excel column to whatever 
											// the row says it should be
											  : rowColumn
											// trim leading/trailing spaces, and 
											// replace linefeeds and embedded spaces 
											// with underscores
											 ).Trim().ReplaceNonAlphaNumeric('_');
				}

				// Delete the header row - i do this here because we've already satisfied 
				// the FirstRowIsHeader condition, and there's really no point in checking 
				// again, just to delete the header row.
				this.ImportedData.Rows.RemoveAt(0);
			}

			// set the table name based on the name of the file (and if Excel file, the 
			// name of the sheet)
			this.ImportedData.TableName = this.BuildTableName();
		}

		/// <summary>
		/// Construct the table name for the datatable. If the ImportedTableName property 
		/// has been set, that name is used regardless of the name of the file. The 
		/// ExcelImportBase class overrides this method, in order to append the sheet 
		/// name.
		/// </summary>
		/// <returns>The name of the table to be used in the ImportedData object</returns>
		protected virtual string BuildTableName()
		{
			// We use either the specified ImportedTableName, or we build the table name 
			// based on the filename and (if this is an excel file) sheet name. I try to 
			// avoid nested ternary conditions, but sometimes, it just makes sense to use 
			// them. In these situations, code formatting goes a long way toward assisting 
			// a programmer who is not familiar with the code base.
			string newTableName = (string.IsNullOrEmpty(this.ImportedTableName)) 
								  ? string.Concat("Imported_", Path.GetFileName(this.FileName).Trim())
								  : this.ImportedTableName;
			return newTableName.ReplaceNonAlphaNumeric('_');
		}

		/// <summary>
		/// Instantiate the hint list with one hint item for every column specified in the 
		/// data table columns. Then, the hint item's type is determined by iterating all 
		/// values for a given column to find the most appropriate type.
		/// </summary>
		protected virtual void CreateColumnHints()
		{
			if (this.AllFieldsAreStrings)
			{
				this.CreateAllStringsColumnHints();
			}
			else if (this.FirstRowDeterminesType)
			{
				this.CreateColumnHintFromFirstCompleteRow();
			}
			else
			{
				// if the programmer hasn't already specified a hints list
				if (this.ColumnHints == null || this.ColumnHints.Count == 0)
				{
					// instantiate
					this.ColumnHints = new ItemHints();

					// for each column in the Columns collection
					for (int i = 0; i < this.ImportedData.Columns.Count; i++)
					{
						// get the column
						DataColumn col = this.ImportedData.Columns[i];
						// if the name isn't null/empty (theoretically impossible, but we 
						// check simply because it's a good idea)
						if (!string.IsNullOrEmpty(col.ColumnName))
						{
							// create a new hint item
							HintItem hint = new HintItem() { Name = col.ColumnName, ColNumb = col.Ordinal, ItemType = null };
							// iterate each row
							foreach (DataRow row in this.ImportedData.Rows)
							{
								// try to determine the best data type based on all of the 
								// possible values
								hint.DetermineType(row[col], this.FileType == ImportFileType.CSV);

								// if we determine at any point that the column should be a 
								// string, we can quit because a string type is our ultimate 
								// fallback data type.
								if (hint.ItemType.Name.IsLike("String"))
								{
									break;
								}
							}
							// add the hint to our list
							this.ColumnHints.Add(hint);
						}
					}
				}
			}
		}

		/// <summary>
		/// Creates a column hints collection where all of the columns are set to the 
		/// string data type.
		/// </summary>
		public virtual void CreateAllStringsColumnHints()
		{
			// instantiate a new collection of hints
			this.ColumnHints = new ItemHints();
			// iterate all of the columns
			foreach (DataColumn col in this.ImportedData.Columns)
			{
				// if the name isn't null/empty (theoretically impossible, but we 
				// check simply because it's a good idea)
				if (!string.IsNullOrEmpty(col.ColumnName))
				{
					// create a new hint item and add it to the column hnts collection
					HintItem hint = new HintItem() { Name = col.ColumnName, ColNumb = col.Ordinal, ItemType = typeof(string) };
					this.ColumnHints.Add(hint);
				}
			}
		}

		/// <summary>
		/// Creates a column hints collection based on the contents of the first row 
		/// only.
		/// </summary>
		protected virtual void CreateColumnHintFromFirstCompleteRow()
		{
			// instantiate a new collection of hints
			this.ColumnHints = new ItemHints();

			// get the first row
			DataRow row = this.ImportedData.Rows[0];

			// iterate all of the columns
			foreach (DataColumn col in this.ImportedData.Columns)
			{
				// if the name isn't null/empty (theoretically impossible, but we 
				// check simply because it's a good idea)
				if (!string.IsNullOrEmpty(col.ColumnName))
				{
					// create a new hint item and add it to the column hnts collection
					HintItem hint = new HintItem() { Name = col.ColumnName, ColNumb=col.Ordinal, ItemType = null };
					hint.DetermineType(row[col], this.FileType == ImportFileType.CSV);
					this.ColumnHints.Add(hint);
				}
			}
			// if a column in the first row is empty, that column will be determined 
			// to be a string column.
		}

		/// <summary>
		/// Reset the column types based on the contents of the columnhints collection.
		/// </summary>
        protected virtual void SetColumnTypes()
        {
            // if we have column hints
            if (this.ColumnHints != null)
            {
				// you can't change the datatype of a column once there are rows in the 
				// datatable, so clone the datatable (brings over schema, but not data)
				using (DataTable cloned = this.ImportedData.Clone())
				{
					// set the column types
					for (int i = 0; i < cloned.Columns.Count; i++)
					{
						cloned.Columns[i].DataType = ColumnHints[i].ItemType;
					}
					for (int i = 0; i < this.ImportedData.Rows.Count; i++)
					{
						DataRow row = this.ImportedData.Rows[i];
						cloned.ImportRow(row);
					}
					// set the imported data to the cloned data table
					this.ImportedData = cloned;
				}
            }
			else
			{
				using (DataTable cloned = this.ImportedData.Clone())
				{
					// set the column types
					for (int i = 0; i < cloned.Columns.Count; i++)
					{
						cloned.Columns[i].DataType = typeof(object);
					}
					for (int i = 0; i < this.ImportedData.Rows.Count; i++)
					{
						DataRow row = this.ImportedData.Rows[i];
						cloned.ImportRow(row);
					}
					// set the imported data to the cloned data table
					this.ImportedData = cloned;
				}
			}
        }

		/* === Public methods ========================================================= */

		/// <summary>
		/// Gets the row/column value by column name. The column index is found, and this 
		/// method then calls the method overload.
		/// </summary>
		/// <param name="row">The row index in the datatable</param>
		/// <param name="columnName">The name of the column in the datab table</param>
		/// <param name="defaultValue">The value to return if the value is null</param>
		/// <returns>An object representing the value at the specified row index/column name</returns>
		public T GetColumnValue<T>(int row, string colName, T defaultValue)
		{
			// sanity checks first
			if (row < 0 || row >= this.ImportedData.Rows.Count)
			{
				throw new ParserAgentException(ParserExceptionEnum.RowIndexOutOfRange, new ArgumentOutOfRangeException(string.Format("Index {0} is out of range (max row index is {1})", row, this.ImportedData.Rows.Count-1)));
			}

			if (string.IsNullOrEmpty(colName))
			{
				throw new ArgumentNullException("Column name parameter cannot bu null or empty.");
			}

			if (!this.ImportedData.Columns.Contains(colName))
			{
				throw new ParserAgentException(ParserExceptionEnum.ColumnDoesNotExist, new ArgumentException(string.Format("Specified column name '{0}' not found in data table", colName)));
			}

			if (this.ColumnHints.FindByColumnName(colName) == null)
			{
				throw new ParserAgentException(ParserExceptionEnum.ColumnDoesNotExist, new ArgumentException(string.Format("Specified column name '{0}' not found in column hints", colName)));
			}

			// if we get here, we're guaranteed a valid column index
			int column = -1;
			for (int i = 0; i < this.ImportedData.Columns.Count; i++)
			{
				if (ImportedData.Columns[i].ColumnName.ToUpper() == colName.ToUpper())
				{
					column = i;
				}
			}
			object value = this.ImportedData.Rows[row].ItemArray[column];
			T result = (value != null) ? (T)value : defaultValue;

			return result;
		}

		/// <summary>
		/// Gets the row/column value by index. 
		/// </summary>
		/// <param name="row">The row index in the datatable</param>
		/// <param name="column">The column index in the datatable</param>
		/// <param name="defaultValue">The value to return if the value is null</param>
		/// <returns>An object representing the value at the specified row/column index</returns>
		public T GetColumnValue<T>(int row, int column, T defaultValue)
		{
			// sanity checks first
			if (row < 0 || row >= this.ImportedData.Rows.Count)
			{
				throw new ParserAgentException(ParserExceptionEnum.RowIndexOutOfRange, new ArgumentOutOfRangeException(string.Format("Index {0} is out of range (max row index is {1})", row, this.ImportedData.Rows.Count-1)));
			}
	
			if (column < 0 || column >= this.ImportedData.Columns.Count)
			{
				throw new ParserAgentException(ParserExceptionEnum.ColumnIndexOutOfRange, new ArgumentOutOfRangeException(string.Format("Column index {0} is out of range (max column index is {1})", column, this.ImportedData.Columns.Count-1)));
			}

			if (column >= this.ColumnHints.Count)
			{
				throw new ParserAgentException(ParserExceptionEnum.ColumnIndexOutOfRange, new ArgumentException(string.Format("Column index {0} is out of range in column hints collection (max column index is {1})", column, this.ColumnHints.Count-1)));
			}	

			T result;
			object value =  this.ImportedData.Rows[row].ItemArray[column];
			result = (value != null) ? (T)value : defaultValue;

			return result;
		}

    }
}


