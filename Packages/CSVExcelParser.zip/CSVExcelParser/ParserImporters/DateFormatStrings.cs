﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParserImporters
{
	public static class DateFormatStrings
	{
		private static string[] formats = new string[]{"F","g", "G", "M", "o", "R", "s","T","t","U", "u", "Y",
													   // I had to add these formats to account for Excel's exporting to csv files.
													   "M/d/yyyy", "M/dd/yyyy"," MM/d/yyyy", "MM/dd/yyyy", 
													   "M/d/yy", "M/dd/yy", "MM/d/yy", "MM/dd/yy"};
		public static string[] Formats
		{
			get { return formats; }
		}

	}
}
