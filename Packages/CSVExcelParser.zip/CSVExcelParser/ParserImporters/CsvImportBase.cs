﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ParserCommon;
using ObjectExtensions;
using System.Globalization;
using System.IO;
using System.Data;
using System.Diagnostics;
using ExcelDataReader;

namespace ParserImporters
{
	/// <summary>
	/// Represents an invalid line that was encountered during the parsing of the file.
	/// </summary>
	public class InvalidLine
	{
		/// <summary>
		/// Get/set the line number of the invalid line (0-based)
		/// </summary>
		public int LineNumber { get; set; }
		/// <summary>
		/// Get/set the text of the invalid line as it exists in the file
		/// </summary>
		public string LineText { get; set; }
		/// <summary>
		/// Get/set the reason the line was invalid.
		/// </summary>
		public string Reason { get; set; }
	}

	/// <summary>
	/// Represents a fairly lightweight CSV file/stream parser. Since this is an abstract class, 
	/// your deriving class should set the config properties before you begin to parse a file.
	/// </summary>
	public abstract class CsvImportBase : ImporterBase
	{
		#region properties

		/// <summary>
		/// Get/set a flag that indicates the importer should fail if it encounters a malformed line
		/// </summary>
		public bool FailOnMalformedLine { get; set; }

		/// <summary>
		/// Get/set the currency symbol to look for when stripping currency symbols. If this value 
		/// is null/empty, the code will use the culture-specific currency symbol as determined by 
		/// the operating system.
		/// </summary>
		public string CurrencySymbol  { get; set; }

		/// <summary>
		/// Get/set the array of values found in the current line
		/// </summary>
		protected string[] CurrentData { get; set; }

		/// <summary>
		/// Get/set the current line being parsed. 
		/// </summary>
		/// <remarks>We do this so we can condct forensic operations on a line that generated an error.</remarks>
		protected string CurrentLine { get; set; }

		/// <summary>
		/// Get/set the list of line indexes for lines that were invalid even after an attempt to auto correct
		/// </summary>
		public List<InvalidLine> InvalidLines  { get; set; }

		/// <summary>
		/// Get/set a flag indicating whether the current line is malformed;
		/// </summary>
		protected bool IsMalformed  { get; set; }

		/// <summary>
		/// Get/set a flag indicating whether or not to remove currency symbols
		/// </summary>
		public bool RemoveCurrencySymbols { get; set; }

		/// <summary>
		/// Get/set flag indicating that enclosing quote characters are to be removed from string data.
		/// </summary>
		public bool RemoveQuotes { get; set; }

		/// <summary>
		/// Get count of total lines processed (good, bad, or otherwise). This value does not count blank lines or the header row.
		/// </summary>
		public int TotalLinesProcessed { get; set; }

		#endregion properties

		#region constructor/destructor

		/// <summary>
		/// Constructor - Initializes this instance of the CSVParser object.
		/// </summary>
		public CsvImportBase(string filename) : base(filename)
		{
			this.Init();
		}

		#endregion constructor/destructor

		/// <summary>
		/// Initializes the base class properties, and then local properties.
		/// </summary>
		protected override void Init()
		{
			// call the base class Init method
			base.Init();

			// set the file type
			this.FileType              = ImportFileType.CSV;

			// unlike the excel importer, we have some additional properties we need to set
			this.RemoveCurrencySymbols = true;
			this.CurrencySymbol        = CultureInfo.CurrentUICulture.NumberFormat.CurrencySymbol;
			this.CurrentLine           = string.Empty;
			this.CurrentData           = null;
			this.IsMalformed           = false;
			this.InvalidLines          = new List<InvalidLine>();
			this.ImportedData          = new DataTable();
			this.TotalLinesProcessed   = 0;
			this.FailOnMalformedLine   = false;
			this.RemoveQuotes          = true;
		}

		/// <summary>
		/// Import the file
		/// </summary>
		public override void Import()
		{
			if (this.CanImport)
			{
				this.Parse();
				base.ProcessData();
            }
		}

		/// <summary>
		/// Parses the actual data from the file/stream, and calls the abstract ProcessFields 
		/// method for every line of data.
		/// </summary>
		protected virtual void Parse()
		{
			// Yes, I'm aware that the ExcelDataReader can import CSV files, but I wanted 
			// more control over the process so I could report on invalid lines, etc.

			this.InvalidLines.Clear();
			try
			{
				using (StreamReader dataStream = new StreamReader(this.FileName))
				{
					this.InvalidLines.Clear();

					// sheet is not going to be null by the time we get here
					string line = string.Empty;
					int lineCounter = -1;

					while ((line = dataStream.ReadLine()) != null)
					{
						lineCounter++;
						// ignore blank lines
						if (string.IsNullOrEmpty(line))
						{
							continue;
						}

						// read the fields in the string. If the line is malformed, this method 
						// will detect that condition and set the IsMalformed property in this 
						// class.
						this.CurrentData = this.ReadFields(lineCounter, line);

						// initialize the data table (if necessary)
						this.InitDataTable(this.CurrentData);

						Debug.WriteLine(line);

						// if the string is malformed, add its index to the InvalidLines list
						if (this.IsMalformed)
						{
							if (this.FailOnMalformedLine)
							{
								throw new ParserAgentException(ParserExceptionEnum.CsvMalformedLine, new InvalidOperationException(string.Format("Line n is malformed.", lineCounter)));
							}
						}
						else
						{
							// we add all rows to the datatable, even the header row (if the file has one).
							this.AddToDataTable(this.CurrentData);
						}

						this.TotalLinesProcessed++;

					} // while ((line = this.DataStream.ReadLine()) != null)
				} // using (StreamReader dataStream = new StreamReader(this.FileName))
			}
			catch (Exception ex)
			{
				throw new Exception("Error parsing file.", ex);
			}
		}

		/// <summary>
		/// Parses a string that represents one row of a CSV file (ostensibly generated by Excel), 
		/// and returns an array of strings that represents each comma-delimited field in that 
		/// string. 
		/// </summary>
		/// <param name="lineCounter">The number of the line being parsed (for indicating invalid lines)</param>
		/// <param name="text">The comma-delimited string to be parsed</param>
		/// <returns>Array of strings found in the specified text</returns>
		protected virtual string[] ReadFields(int lineCounter, string text)
		{
			//assume we have a proper line of text
			this.IsMalformed = false;

			// split the string on commas (because this is a CSV file, after all)
			string[] parts = text.Trim().Split(',');

			// create a container for our results
			List<string> newParts = new List<string>();

			// set some initial values
			bool inQuotes = false;
			string currentPart = string.Empty;

			// iterate the parts array
			for (int i = 0; i < parts.Length; i++)
			{
				// get the part at the current index
				string part = parts[i];

				// if we're in a quoted string and the current part starts with a single double 
				// quote AND currentPart isn't empty, assume the currentPart is complete, add it to 
				// the newParts list, and reset for the new part
				if (inQuotes && part.StartsWithSingleDoubleQuote() == true && !string.IsNullOrEmpty(currentPart))
				{
					currentPart = string.Concat(currentPart, "\"");
					newParts.Add(currentPart);
					currentPart = string.Empty;
					inQuotes = false;
				}

				// see if we're in a quoted string
				inQuotes = (inQuotes || (!inQuotes && part.StartsWithSingleDoubleQuote() == true));

				// if so, add the part to the current currentPart
				if (inQuotes)
				{
					currentPart = (string.IsNullOrEmpty(currentPart)) ? part : string.Format("{0},{1}", currentPart, part);
				}
				// otherwise, simply set the currentPart to the part
				else
				{
					currentPart = part;
				}

				// see if we're still in a quoted string
				inQuotes = (inQuotes && currentPart.EndsWithSingleDoubleQuote() == false);
				// if not
				if (!inQuotes)
				{
					// remove the quote characters
					currentPart = (this.RemoveQuotes) ? currentPart.Trim('\"') : currentPart;
					// put the currentPart into our container
					newParts.Add(currentPart);
					// reset the currentPart
					currentPart = string.Empty;
				}
			}

			// determine if the line is somehow invalid, and if it is, save it
			this.IsMalformed = (inQuotes || this.ImportedData.Columns.Count > 0 && newParts.Count != this.ImportedData.Columns.Count);
			if (this.IsMalformed)
			{
				string reason = (inQuotes) ? "Missing end-quote" : "Missing at least one column";
				this.InvalidLines.Add(new InvalidLine() { LineNumber = lineCounter, LineText = text, Reason = reason });
			}

			return newParts.ToArray();
		}

		/// <summary>
		/// Initialize the datatable. If it's null, instantiate it. If the number of 
		/// defined columns is zero, assume that the parts array is the header.
		/// </summary>
		/// <param name="parts"></param>
        protected virtual void InitDataTable(string[] parts)
        {
            if (this.ImportedData == null)
            {
                this.ImportedData = new DataTable();
            }
			// if the columns have not yet been defined, we need to create them.
            if (this.ImportedData.Columns.Count == 0)
            {
                for (int i = 0; i < parts.Length; i++)
                {
					// If the first row contains headers, use the contents of the parts 
					// array to specify the names. Otherwise, set the column names to 
					// "Column_n" where "n" is the current index into the parts array.
                    this.ImportedData.Columns.Add((this.FirstRowIsHeader) ? parts[i] : string.Format("Column_{0}", i + 1), typeof(object));
                }
            }
        }

		/// <summary>
		/// Adds a row to the datatable (initializes the columns if the datatable is new).
		/// </summary>
		/// <param name="parts"></param>
		protected virtual void AddToDataTable(string[] parts)
		{
			// Create a new row. New rows contain n items in the ItemArray property. The 
			// number of items is determined by the number of columns the datatable has.
			DataRow row = this.ImportedData.NewRow();
			// now add our parts to the row
			for (int i = 0; i < parts.Length; i++)
			{
				string part = parts[i];
				if (!string.IsNullOrEmpty(this.CurrencySymbol))
				{
					part = (part.StartsWith(this.CurrencySymbol) || part.EndsWith(this.CurrencySymbol)) ? part.Replace(this.CurrencySymbol, "").Replace(",", "") : part;
				}
				part = part.Replace("\"", "").Trim();
				row[i] = part;
			}
			// add the new row to the datatable.
			this.ImportedData.Rows.Add(row);

			// Yes, we are adding the header row (if there is a header row), but before 
			// we determine data types, we'll be deleting it, so no harm no foul.
		}

	}
}
