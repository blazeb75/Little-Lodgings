﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParserImporters
{
	public enum TablePrepAction 
	{ 
		/// <summary>
		/// Indicates that data wll be appended to the existing table
		/// </summary>
		None, 
		/// <summary>
		/// Indicates that the table will be dropped
		/// </summary>
		Drop, 
		/// <summary>
		/// Indicates that the table will be truncated
		/// </summary>
		Truncate 
	};

	public enum ImportFileType
	{
		CSV,
		EXCEL
	};

	// when parsing CSV files, an error can occur if there are missing fields
	public enum ParseErrorAction
	{
		/// <summary>
		/// Delete malformed rows without throwing an exception
		/// </summary>
		Ignore,
		/// <summary>
		/// Throw an exception
		/// </summary>
		Notify
	}
}
