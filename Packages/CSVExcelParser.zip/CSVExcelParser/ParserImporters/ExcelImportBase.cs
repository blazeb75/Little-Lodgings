﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ParserCommon;
using ObjectExtensions;
using System.Data;
using System.IO;
using ExcelDataReader;
using System.Globalization;

namespace ParserImporters
{
	/// <summary>
	/// Base class for importing excel spreadsheets
	/// </summary>
	public abstract class ExcelImportBase : ImporterBase
	{
		/// <summary>
		/// Get/set the name of the file's worksheet that is to be imported.
		/// </summary>
		public string SheetName { get; set; }

		/// <summary>
		/// Instantiates this object.
		/// </summary>
		/// <param name="filename">The name of the file to load.</param>
		/// <param name="sheetName">The name of the worksheet to parse.</param>
		public ExcelImportBase(string filename, string sheetName) : base(filename)
		{
			this.SheetName = sheetName;
			// initialize the properties that control how the importer functions
			this.Init();
		}

		/// <summary>
		/// Initialize this object with default property values.
		/// </summary>
		protected override void Init()
		{
			base.Init();
			this.FileType = ImportFileType.EXCEL;
		}

		/// <summary>
		/// Performs sanity checks on the filename, the worksheet name, and the database name
		/// </summary>
		protected override void DoSanityChecks()
		{
			base.DoSanityChecks();
			if (this.CanImport)
			{
				if (this.FileType == ImportFileType.EXCEL)
				{
					if (string.IsNullOrEmpty(this.SheetName))
					{
						this.CanImport = false;
						throw new ParserAgentException(ParserExceptionEnum.InvalidSheetName);
					}
				}
			}
		}


		/// <summary>
		/// Import the specified sheet from the file. This method overrides the abstract 
		/// method in the base class.
		/// </summary>
		public override void Import()
		{
			if (this.CanImport)
			{
				// load the worksheet from the file
				this.ImportedData  = this.ReadSheet(this.FileName, this.SheetName);
				// process the data
				base.ProcessData();
			}
		}

		/// <summary>
		/// Build the table name. If the ImportedTableName property is set by the 
		/// programmer, the sheet name will NOT be added to it.
		/// </summary>
		/// <returns></returns>
		protected override string BuildTableName()
		{
			string newTableName = base.BuildTableName();
			newTableName = (!string.IsNullOrEmpty(this.ImportedTableName)) 
							? this.ImportedTableName 
							: string.Concat(newTableName, "_", this.SheetName.Trim());
			return newTableName.ReplaceNonAlphaNumeric('_');
		}

		/// <summary>
		/// Reads the specified sheet and returns a DataTable object.
		/// </summary>
		/// <param name="filename">The name of the file conbtaining the desired worksheet</param>
		/// <param name="sheetName">The name of the worksheet from which to import</param>
		/// <returns>Datatable with content from source</returns>
		protected virtual DataTable ReadSheet(string filename, string sheetName)
		{
			DataSet ds = null;
			DataTable data  = null;
			try
			{
				using (System.IO.FileStream stream = File.Open(filename, FileMode.Open, FileAccess.Read))
				{
					// all of the heavy lifting is performed by the ExcelDataReader library.
					using (var reader = ExcelDataReader.ExcelReaderFactory.CreateReader(stream))
					{
						do
						{
							if (reader.Name.IsLike(sheetName))
							{
								ds = reader.AsDataSet();
							}
						} while (reader.NextResult());
					}
					if (ds != null)
					{
						data = ds.Tables[0];
					}
				}
			}
			catch (Exception ex)
			{
				throw new ParserAgentException(ParserExceptionEnum.ExcelDataReaderError, ex);
			}
			return data;
		}

    }
}
