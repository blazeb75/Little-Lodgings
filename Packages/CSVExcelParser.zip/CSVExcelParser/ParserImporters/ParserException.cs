﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParserImporters
{
	public enum ParserExceptionEnum
	{
		Unknown=999,
		// Import exceptions (100-199)
        NotSpecified = 100,
        NoInitialCatalog,
        InvalidFileName,
        ImportFileNotFound,
        InvalidSheetName,
        InvalidConnString,
        ExcelDataReaderError,
        CsvMalformedLine,
        ColumnDoesNotExist,
        ColumnIndexOutOfRange,
        RowIndexOutOfRange,

		// If you want to add more exceptions, start at a value evenly divisible by 10 starting at 301 
		DevDefinedErrors=300,
	};

	public static class ParserExceptionCodes
	{
		public static Dictionary<int, string> Codes { get; set; }
		static ParserExceptionCodes()
		{
			ParserExceptionCodes.Codes = new Dictionary<int,string>();
			Codes.Add((int)ParserExceptionEnum.Unknown,                         "Unknown error - something bad happened that the application was not anticipating.");

			Codes.Add((int)ParserExceptionEnum.NotSpecified,                    "Not specified");
			Codes.Add((int)ParserExceptionEnum.NoInitialCatalog,                "InitialCatalog (Database) not found in connection string.");
			Codes.Add((int)ParserExceptionEnum.InvalidFileName,                 "Filename cannot be null/empty");
			Codes.Add((int)ParserExceptionEnum.ImportFileNotFound,              "Import source file not found");
			Codes.Add((int)ParserExceptionEnum.InvalidSheetName,                "Sheetname cannot be null/empty");
			Codes.Add((int)ParserExceptionEnum.InvalidConnString,               "Connection string cannot be null/empty");
			Codes.Add((int)ParserExceptionEnum.ExcelDataReaderError,            "Error loading Excel file.");
			Codes.Add((int)ParserExceptionEnum.CsvMalformedLine,                "CSV importer encountered malformed line");
			Codes.Add((int)ParserExceptionEnum.ColumnDoesNotExist,              "Specified column does not exist.");
			Codes.Add((int)ParserExceptionEnum.ColumnIndexOutOfRange,           "Specified datatable column index is out of range.");
			Codes.Add((int)ParserExceptionEnum.RowIndexOutOfRange,              "Specified datatable row index is out of range.");
			//Codes.Add((int)ParserExceptionEnum, "");
			//Codes.Add((int)ParserExceptionEnum, "");
			//Codes.Add((int)ParserExceptionEnum, "");
			//Codes.Add((int)ParserExceptionEnum, "");
			//Codes.Add((int)ParserExceptionEnum, "");
			//Codes.Add((int)ParserExceptionEnum, "");
		}
	}

	public class ParserAgentException : Exception
	{
		public int ReturnValue { get; set; }

		public ParserAgentException()
		{
			this.ReturnValue = (int)ParserExceptionEnum.NotSpecified;
		}

		public ParserAgentException(string message) : base(message)
		{
			this.ReturnValue = (int)ParserExceptionEnum.NotSpecified;
		}

		public ParserAgentException(string message, Exception inner) : base(message, inner)
		{
			this.ReturnValue = (int)ParserExceptionEnum.NotSpecified;
		}

		public ParserAgentException(ParserExceptionEnum result):base (ParserExceptionCodes.Codes[(int)result])
		{
			this.ReturnValue = (int)result;
		}

		public ParserAgentException(ParserExceptionEnum result, Exception inner):base (ParserExceptionCodes.Codes[(int)result], inner)
		{
			this.ReturnValue = (int)result;
		}

	}
}
