﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObjectExtensions;
using System.Globalization;

namespace ParserImporters
{
	/// <summary>
	/// Represents a hint item, which is used to determine the datatype of a given column.
	/// </summary>
	public class HintItem
	{
		private string name;

		/// Get/set the name of the column. The name needs to be "normalized" by the 
		/// importer BEFORE you create a hint item. The same as the "massaged" name we 
		/// come up with below (we replace non-alphanumeric characters with underscores).
		public string Name     
		{ 
			get
			{
				return this.name;
			}
			set
			{
				this.name = value.ReplaceNonAlphaNumeric("_");
			}
		}

		/// <summary>
		/// The data type as determined by the DetermineType method
		/// </summary>
		public Type   ItemType { get; set; }

		/// <summary>
		/// Get/set the column index (set with the value of the datatable column Ordinal 
		/// property)
		/// </summary>
		public int    ColNumb  { get; set; }

		/// <summary>
		/// Determines the data type of the column. If the value is null/empty, the column is 
		/// determined to be a string.
		/// </summary>
		/// <param name="value">The value to be examined</param>
		/// <param name="fromCSV">True if this is being dne in a CSV importer.</param>
		public void DetermineType(object value, bool fromCSV=false)
		{
			// if the type isn't already a string
			if (this.ItemType == null || !this.ItemType.Name.IsLike("String"))
			{
				Type theType = this.ItemType;

				// we have to check if its from a CSV import becaus everything imported 
				// from a CSV defaults to string.
				if (value is string && !fromCSV)
				{
					theType = typeof(String);
				}
				else
				{
					string valueStr = value.ToString();

					DateTime parsedDateTime;
					Int32    parsedInt32;
					double   parsedDouble;
					bool     parsedBool;

					// We try to parse the value using all standard datetime formats 
					// (custom formats are not supported unless you want to modify the 
					// DateFormatStrings object.).
					if (DateTime.TryParseExact(valueStr, DateFormatStrings.Formats, CultureInfo.CurrentUICulture, DateTimeStyles.None, out parsedDateTime))
					{
						theType = typeof(DateTime);
					}
					else if (Int32.TryParse(valueStr, out parsedInt32))
					{
						// we only want to change the type if it's not already a double
						if (theType == null || !theType.Name.IsLike("Double"))
						{
							theType = typeof(Int32);
						}
					}
					else if (double.TryParse(valueStr, out parsedDouble))
					{
						theType = typeof(Double);
					}
					else if (bool.TryParse(valueStr, out parsedBool))
					{
						theType = typeof(Boolean);
					}
					else 
					{
						theType = typeof(String);
					}
				}
				this.ItemType = theType;
			}
		}
	}

	/// <summary>
	/// Represents a list of hint items.
	/// </summary>
	public class ItemHints:List<HintItem>
	{
		/// <summary>
		/// Get the column represented by the specified *case-sensitive* column name.
		/// </summary>
		/// <param name="name">The case-sensitive name of the column</param>
		/// <returns>The found hint item (or null of not found)</returns>
		public HintItem FindByColumnName(string name)
		{
			return this.FirstOrDefault(x=>x.Name == name);
		}

		/// <summary>
		/// Removes the specified hint item.
		/// </summary>
		/// <param name="name">Name of the column (can be decorated with SQL wildcard characters)</param>
		public void Remove(string name)
		{
			HintItem found = this.FirstOrDefault(x=>x.Name.IsLike(name));
			if (found != null)
			{
				this.Remove(found);
			}
		}

		/// <summary>
		/// Removes the specified hint item.
		/// </summary>
		/// <param name="columnNumber">The 0-based column index of the column to be removed.</param>
		public void Remove(int columnNumber)
		{
			HintItem found = this.FirstOrDefault(x=>x.ColNumb == columnNumber);
			if (found != null)
			{
				this.Remove(found);
			}
		}
	}

}
