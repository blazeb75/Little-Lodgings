﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObjectExtensions;
using ParserImporters;

namespace CsvExcelParserConsole
{
	public class CSVItem
	{
		public int ID            { get; set; }
		public string Comment    { get; set; }
		public DateTime The_Date { get; set; }
		public double FloatValue { get; set; }
		public int IntValue      { get; set; }
		public string IPAddress  { get; set; }
		public double Currency   { get; set; }
	}

	public class CSVItems : List<CSVItem>
	{
		/// <summary>
		/// Add the entire data table collection to this collection, using DataTableReader extension methods.
		/// </summary>
		/// <param name="data">The datatable that represents the imported data</param>
		public void Add(DataTable data)
		{
			try
			{
				// I already have a set of extension methods to extract column data from a 
				// DataTableReader object (these methods do all the casting and sets default 
				// values), so it's a simple matter create a DataTableReader from the 
				// DataTable to utilize these existing methods.
				using (DataTableReader reader = data.CreateDataReader())
				{
					if (reader.HasRows)
					{
						int ORD_ID     = reader.GetOrdinal("ID");
						int ORD_COMM   = reader.GetOrdinal("Comment");
						int ORD_DATE   = reader.GetOrdinal("The_Date");
						int ORD_FLOATV = reader.GetOrdinal("FloatValue");
						int ORD_INTV   = reader.GetOrdinal("IntValue");
						int ORD_IP     = reader.GetOrdinal("IPAddress");
						int ORD_CURR   = reader.GetOrdinal("Currency");

						while (reader.Read())
						{
							this.Add(new CSVItem()
							{
								ID         = reader.GetInt32OrDefault   (ORD_ID,     0),
								Comment    = reader.GetStringOrDefault  (ORD_COMM,   "No Comment specified"),
								The_Date   = reader.GetDateTimeOrDefault(ORD_DATE,   new DateTime(0)),
								FloatValue = reader.GetDoubleOrDefault  (ORD_FLOATV, 0d),
								IntValue   = reader.GetInt32OrDefault   (ORD_INTV,   0),
								IPAddress  = reader.GetStringOrDefault  (ORD_IP,     "1.0.0.0"),
								Currency   = reader.GetDoubleOrDefault  (ORD_CURR,   0d),
							});
						}
					}
				}
			}
			catch (Exception ex)
			{
				throw new Exception("Exception encountered while storing data into a list of objects", ex);
			}
		}

		/// <summary>
		/// Add the entire data table collection to this collection, using the importer object 
		/// GetColumnValue method.
		/// </summary>
		/// <param name="loader">The importer that contains the imported data</param>
		public void Add(CsvImportBase loader)
		{
			try
			{
				// The loader has a method called GetColumnValue which requires less code than 
				// the extsnion methods described above. Most of you will probably prefer to 
				// use those methods.
				for (int row = 0; row < loader.ImportedData.Rows.Count; row++)
				{
					this.Add(new CSVItem()
					{
						ID         = loader.GetColumnValue(row, "ID",         0),
						Comment    = loader.GetColumnValue(row, "Comment",    "No Comment specified"),
						The_Date   = loader.GetColumnValue(row, "The_Date",   new DateTime(0)),
						FloatValue = loader.GetColumnValue(row, "FloatValue", 0d),
						IntValue   = loader.GetColumnValue(row, "IntValue",   0),
						IPAddress  = loader.GetColumnValue(row, "IPAddress",  "1.0.0.0"),
						Currency   = loader.GetColumnValue(row, "Currency",   0d),
					});
				}
			}
			catch (Exception ex)
			{
				throw new Exception("Exception encountered while storing data into a list of objects", ex);
			}
		}
	}
}
