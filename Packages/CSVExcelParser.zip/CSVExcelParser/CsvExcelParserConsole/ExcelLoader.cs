﻿using ParserImporters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsvExcelParserConsole
{
	/// <summary>
	/// This is your Excel importer class. Since the base class is abstract, you MUST 
	/// derive your own class from it.
	/// </summary>
	public class ExcelLoader : ExcelImportBase
	{
		// At the very least, you have to provide a constructor that calls the Init method. 
		// After that, it's all automatic.
		public ExcelLoader(string filename, string sheetname) : base(filename, sheetname)
		{
		}

		//////////////////////////////////////////////////////////////////////////////////
		// If you want to change the process involved in importing and parsing data, you 
		// can override the Import method. However, that would essentially mean that you 
		// want to "roll your own", which would kinda make using my code pointless. :)
		//public override void Import()
		//{
		//	try
		//	{
		//		
		//	}
		//	catch (Exception ex)
		//	{
		//	}
		//}

		//////////////////////////////////////////////////////////////////////////////////
		// If you want to change the property initization of the base class, you can 
		// override the init method here. 
		//protected override void Init()
		//{
		//}


		//////////////////////////////////////////////////////////////////////////////////
		// You only need to override and call this method if you want to manually 
		// specify column data types for the data being imported. The default version of 
		// this method does a pretty good job, so this should rarely (if ever) be 
		// necessary. If you DO override this method, you should call it from an 
		// overridden Init method so that the ColumnHints object exists BEFORE the file 
		// is loaded and parsed.
		//protected override void CreateColumnHints()
		//{
		//	
		//	// TO-DO: If you want to omit columns being imported, remove the hint items 
		//	//        here. You can remove columns beither by name, or by column index, 
		//	//        using code like you see below. If the indicated column doesn't 
		//	//        exist, no exception will be thrown.
		//}
	}
}
