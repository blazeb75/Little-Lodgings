﻿using ParserImporters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CsvExcelParserConsole
{
	class Program
	{
		/// <summary>
		/// Get/set the path to the executing assembly (this application)
		/// </summary>
		private static string AppPath { get; set; }
		private static CSVItems csvItems = new CSVItems();

		static void Main(string[] args)
		{
			// I didn't bother using the commandline args because this is just an example 
			// of how to use the importer classes, and it's easier to hard-code the 
			// filenames where necessary. The sample data files used in this sample app 
			// are part of this project and will be copied to the executable folder when 
			// the solution is compiled.

			// get the executing asembly's directory name
			string codeBase = Assembly.GetExecutingAssembly().CodeBase;
			UriBuilder uri = new UriBuilder(codeBase);
			AppPath = System.IO.Path.GetDirectoryName(Uri.UnescapeDataString(uri.Path).ToLower().Replace("/", @"\"));

			ImportCSV();
			ImportExcel();
		}

		/// <summary>
		/// Import the sample CSV file
		/// </summary>
		private static void ImportCSV()
		{
            string filename = System.IO.Path.Combine(AppPath, @"testdata\sample1.csv");
			CSVLoader loader = null;
            try
            {
				//instantiate the importer class
                loader = new CSVLoader(filename);

				// call the import method
                loader.Import();

				//DateTime example = Convert.ToDateTime(loader.ImportedData.Rows[0]["Currency"]);

				//csvItems.Add(loader.ImportedData);
				csvItems.Add(loader);

				// display the results to the user
				ShowMetrics(loader);

				// After the import is performed, you can use the ImportedData property 
				// (a DataTable object) to work with the data in a way that is 
				// appropriate for your application.
            }
            catch (Exception ex)
            {
				// This line is because I don't like warnings when I compile, but I 
				// still need to be able to examine the Exception variable. Ir also 
				// provides a handy place to put a breakpoint so I can examine 
				// exceptions that are thrown.
				if (ex != null) { }
            }
		}

		/// <summary>
		/// Import the sample Excel file
		/// </summary>
		private static void ImportExcel()
		{
			string filename = System.IO.Path.Combine(AppPath, @"testdata\sample1.xlsx");

			ExcelLoader loader = null;
			try
			{
				//instantiate the importer class
				loader = new ExcelLoader(filename, "sheet1");

				// call the import method
				loader.Import();

				// display the results to the user
				ShowMetrics(loader);
			}
			catch (Exception ex)
			{
				// This line is because I don't like warnings when I compile, but I 
				// still need to be able to examine the Exception variable. Ir also 
				// provides a handy place to put a breakpoint so I can examine 
				// exceptions that are thrown.
				if (ex != null) { }
			}
		}

		/// <summary>
		/// Show the output to the user
		/// </summary>
		/// <param name="filename"></param>
		/// <param name="data"></param>
		private static void ShowMetrics(ImporterBase loader)
		{
			// ImportedData is a DataTable that contains the imported data. You can 
			// use it to inspect/manipulate the data. For our purposes in this sample 
			// application, we're simply streaming some of the interesting properties 
			// to the console.
			Console.WriteLine(string.Format("{0}", new String('=', 80)));
			Console.WriteLine(string.Format("Imported filename = {0}", loader.FileName));
			Console.WriteLine(string.Format("  Table name    = {0}", loader.ImportedData.TableName));
			Console.WriteLine(string.Format("  Rows imported = {0}", loader.ImportedData.Rows.Count));
			Console.WriteLine(string.Format("  Columns found = {0}", loader.ImportedData.Columns.Count));
			for (int i = 0; i < loader.ImportedData.Columns.Count; i++)
			{
				Console.WriteLine(string.Format("      Column {0}: Name = {1}, Type = {2}",
												i + 1,
												loader.ImportedData.Columns[i].ColumnName,
												loader.ImportedData.Columns[i].DataType));
			}
			if (loader is CsvImportBase)
			{
				var invalidLines = ((CsvImportBase)loader).InvalidLines;
				if (invalidLines.Count > 0)
				{
					Console.WriteLine(string.Format("{0}", new String('-', 80)));
					Console.WriteLine("Invalid lines were detected:");
					Console.WriteLine("LINE#  REASON                       LINE TEXT");
					foreach (InvalidLine line in invalidLines)
					{
						string msg = string.Format("{0,-5}  {1,-27}  {2}", line.LineNumber, line.Reason, line.LineText);
						Console.WriteLine(msg);
					}
				}
			}
			Console.WriteLine("END");
			Console.ReadKey();
		}
	}


}
